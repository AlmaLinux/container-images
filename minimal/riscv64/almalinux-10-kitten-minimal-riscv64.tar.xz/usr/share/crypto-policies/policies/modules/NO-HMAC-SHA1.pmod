# This is an example subpolicy disabling SHA-1 HMAC support.

mac = -HMAC-SHA1
